import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt

img = cv.imread('graffiti.png', cv.IMREAD_GRAYSCALE)
